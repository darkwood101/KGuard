In the Linux source, only files that we added or modified are included. Those
files are not included completely, but only the portions of the files that
were changed.

For the full source of the modified kernel, see https://github.com/darkwood101/KGuard. 
